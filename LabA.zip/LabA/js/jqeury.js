function makeBigger() {
    "use strict";
    $("#pTag").css("font-size", "100px");
}
function makeSmaller() {
    "use strict";
    $("#pTag").css("font-size", "25px");
}
function makeBlue() {
    "use strict";
    $("#pTag").css("color", "blue");
}
function makeGreen() {
    "use strict";
    $("#pTag").css("color", "green");
}
function makeBlack() {
    "use strict";
    $("#pTag").css("color", "black");
}
function makeNone() {
    "use strict";
    $("#pTag").css("display", "none");
}
function makeBlock() {
    "use strict";
    $("#pTag").css("display", "block");
}
function reset() {
    "use strict";
    $("#pTag").css("font-size", "50px");
    $("#pTag").css("display", "block");
    $("#pTag").css("color", "black");
}